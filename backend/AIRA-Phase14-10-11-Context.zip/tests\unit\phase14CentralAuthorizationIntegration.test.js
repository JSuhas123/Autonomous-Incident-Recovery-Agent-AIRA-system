"use strict";

const fs =
  require(
    "fs"
  );

const path =
  require(
    "path"
  );


const middlewarePath =
  path.join(
    __dirname,
    "..",
    "..",
    "middleware",
    "authorizationMiddleware.js"
  );


const centralPath =
  path.join(
    __dirname,
    "..",
    "..",
    "services",
    "identity",
    "centralAuthorizationService.js"
  );


const principalPath =
  path.join(
    __dirname,
    "..",
    "..",
    "services",
    "identity",
    "principalService.js"
  );


describe(
  "Phase 14.6B central authorization integration",
  () => {

    test(
      "legacy requirePermission delegates to central authorization",
      () => {
        const source =
          fs.readFileSync(
            middlewarePath,
            "utf8"
          );

        expect(
          source
        ).toContain(
          "centralAuthorizationService"
        );

        expect(
          source
        ).toMatch(
          /\bauthorize\s*\(/
        );
      }
    );


    test(
      "authorization middleware resolves a canonical principal",
      () => {
        const source =
          fs.readFileSync(
            middlewarePath,
            "utf8"
          );

        expect(
          source
        ).toContain(
          "principalFromRequest"
        );

        expect(
          source
        ).toContain(
          "req.principal"
        );
      }
    );


    test(
      "authorization middleware no longer independently calls can for normal central path",
      () => {
        const source =
          fs.readFileSync(
            middlewarePath,
            "utf8"
          );

        /**
         * Phase 14.1 legacy compatibility may still use can() inside its
         * tightly-scoped compatibility branch.
         *
         * What we want to prevent is the previous normal-path pattern:
         *
         *     can(principal, permission)
         *
         * being used as the main authorization mechanism instead of
         * centralAuthorizationService.authorize().
         *
         * The central authorize() call must therefore be present.
         */

        expect(
          source
        ).toMatch(
          /\bauthorize\s*\(/
        );

        expect(
          source
        ).toContain(
          "NORMAL PHASE 14.6 CENTRAL AUTHORIZATION"
        );
      }
    );


    test(
      "central authorization remains organization scoped",
      () => {
        const source =
          fs.readFileSync(
            centralPath,
            "utf8"
          );

        expect(
          source
        ).toContain(
          "ORGANIZATION_SCOPE_MISMATCH"
        );

        expect(
          source
        ).toContain(
          "checkOrganizationScope"
        );
      }
    );


    test(
      "central authorization remains environment aware",
      () => {
        const source =
          fs.readFileSync(
            centralPath,
            "utf8"
          );

        expect(
          source
        ).toContain(
          "ENVIRONMENT_SCOPE_DENIED"
        );

        expect(
          source
        ).toContain(
          "checkEnvironmentScope"
        );
      }
    );


    test(
      "principal resolution supports established req.auth session identity",
      () => {
        const source =
          fs.readFileSync(
            principalPath,
            "utf8"
          );

        expect(
          source
        ).toMatch(
          /req\.auth[\s\S]*?userId/
        );

        expect(
          source
        ).toMatch(
          /req\.auth[\s\S]*?organizationId/
        );

        expect(
          source
        ).toMatch(
          /req\.auth[\s\S]*?role/
        );
      }
    );


    test(
      "authorization middleware preserves fail-closed execution state",
      () => {
        const source =
          fs.readFileSync(
            middlewarePath,
            "utf8"
          );

        expect(
          source
        ).toContain(
          "executionAuthorized"
        );

        expect(
          source
        ).toContain(
          "false"
        );
      }
    );
  }
);